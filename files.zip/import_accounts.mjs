// One-time import of your existing 493 accounts into Supabase.
//
// Setup:
//   npm install @supabase/supabase-js
//   node import_accounts.mjs
//
// Expects all_accounts_export.json (from your handoff) in the same folder.

import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';

const SUPABASE_URL = 'YOUR_PROJECT_URL_HERE';       // e.g. https://abcdefgh.supabase.co
const SUPABASE_KEY  = 'YOUR_SERVICE_ROLE_KEY_HERE';  // Project Settings > API > service_role
// Use the service_role key ONLY for this one-off import script, run locally.
// Never put the service_role key in any code that ships to a browser -
// the app itself must use the anon public key instead (see index.html).

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const raw = JSON.parse(readFileSync('./all_accounts_export.json', 'utf8'));

function toRow(a) {
  return {
    id: a.id,
    name: a.name || '',
    hubspot_id: a.hubspotId || null,
    category: a.category || null,
    current_system: a.currentSystem || null,
    contract_expiry: a.contractExpiry || null,
    deal_value: a.dealValue || null,
    stage: a.stage || 'not_started',
    notes: a.notes || null,
    contact: a.contact || null,
    role: a.role || null,
    sector: a.sector || null,
    next_step: a.nextStep || null,
    due: a.due || null,
  };
}

const rows = raw.map(toRow);

// Batch in chunks of 100 - gentler on the API and easier to see progress.
const CHUNK = 100;
let imported = 0;

for (let i = 0; i < rows.length; i += CHUNK) {
  const batch = rows.slice(i, i + CHUNK);
  const { error } = await supabase.from('accounts').upsert(batch, { onConflict: 'id' });
  if (error) {
    console.error(`Batch ${i / CHUNK + 1} failed:`, error.message);
    process.exit(1);
  }
  imported += batch.length;
  console.log(`Imported ${imported} / ${rows.length}`);
}

console.log('Done. Verify in Supabase: Table Editor > accounts.');
