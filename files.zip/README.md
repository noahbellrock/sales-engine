# Setup

## 1. Create the Supabase project
Go to supabase.com, sign up free, "New Project". Takes about 2 minutes to provision.

## 2. Create the table
In your project: **SQL Editor** > **New query** > paste the contents of `schema.sql` > **Run**.

## 3. Get your credentials
**Project Settings > API**. You'll see:
- **Project URL** (e.g. `https://abcdefgh.supabase.co`)
- **anon / public key** — safe to use in browser code, goes in `index.html`
- **service_role key** — powerful, bypasses all security rules. Use it ONLY in
  `import_accounts.mjs`, run locally on your own machine, never in any file
  that ends up in a browser or a public GitHub repo.

## 4. Import your existing 493 accounts
Put `all_accounts_export.json` (from your handoff) in this same folder, then:
```
npm install @supabase/supabase-js
```
Edit the two placeholder values at the top of `import_accounts.mjs`, then:
```
node import_accounts.mjs
```
You should see it count up to 493. Check **Table Editor > accounts** in Supabase to confirm.

## 5. Wire up the app
Edit the two placeholder values at the top of `index.html` (URL + anon key, not the service key).
Open `index.html` directly in a browser to test locally first - it should load your real accounts.

## 6. Put it on GitHub and deploy
```
git init
git add .
git commit -m "Initial Supabase-backed version"
```
Create a repo on GitHub, push to it. Then on vercel.com: "New Project" > import that repo > Deploy.
Vercel will detect it's a static site and just serve `index.html` - no build config needed.

## 7. Extend it
Use Claude Code or Cursor in VS Code, pointed at this folder plus your original
`concerto-final.html` as reference, to carry over whatever else you want
(charts, filters, the other views) - the save/load pattern in `index.html` is
the part to reuse for every new field or view you add.
