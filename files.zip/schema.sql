-- Run this once in Supabase: Project > SQL Editor > New query > paste > Run

create table if not exists accounts (
  id           text primary key,
  name         text not null,
  hubspot_id   text,
  category     text,
  current_system text,
  contract_expiry text,
  deal_value   text,
  stage        text not null default 'not_started'
                 check (stage in ('not_started','attempting','in_pipe','not_interested','customer')),
  notes        text,
  contact      text,
  role         text,
  sector       text,
  next_step    text,
  due          text,
  updated_at   timestamptz not null default now()
);

-- Keep updated_at current on every edit, automatically, server-side.
-- This alone gives you an audit trail the old setup never had.
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists accounts_set_updated_at on accounts;
create trigger accounts_set_updated_at
  before update on accounts
  for each row execute function set_updated_at();

-- Row Level Security: start permissive (anyone with the anon key can read/write),
-- which is fine while it's just you. Tighten later with real auth if others join.
alter table accounts enable row level security;

drop policy if exists "allow all for now" on accounts;
create policy "allow all for now" on accounts
  for all using (true) with check (true);
